package TransactionApp;

public class TransactionManagement {
	private Transaction[] allTransactions = new Transaction[1500];
    private Transaction[][] twoDTransactionMatrix = new Transaction[100][15];
    private ShopAssistant[] shopAssistantsArray = new ShopAssistant[100];
    private SalaryManagement salaryManagement;
    public TransactionManagement() {
    	this.allTransactions=allTransactions();
    	this.shopAssistantsArray = sepTransactions();
    	salaryManagement = new SalaryManagement(this.shopAssistantsArray);
    	this.twoDTransactionMatrix = voidTransactionMatrix();
    	
    }
    
    public Transaction[] getAllTransactions() {
		return allTransactions;
	}

	public void setAllTransactions(Transaction[] allTransactions) {
		this.allTransactions = allTransactions;
	}

	public Transaction[][] getTwoDTransactionMatrix() {
		return twoDTransactionMatrix;
	}

	public void setTwoDTransactionMatrix(Transaction[][] twoDTransactionMatrix) {
		this.twoDTransactionMatrix = twoDTransactionMatrix;
	}

	public ShopAssistant[] getShopAssistantsArray() {
		return shopAssistantsArray;
	}

	public void setShopAssistantsArray(ShopAssistant[] shopAssistantsArray) {
		this.shopAssistantsArray = shopAssistantsArray;
	}

	public SalaryManagement getSalaryManagement() {
		return salaryManagement;
	}

	public void setSalaryManagement(SalaryManagement salaryManagement) {
		this.salaryManagement = salaryManagement;
	}

	  public Transaction getMinPriceTransaction() {
	    	double minPrice = 50000;
	    	Transaction minPriceTransaction = new Transaction();
	    	for(Transaction element: allTransactions) {
	        	if(element.getTotPrice() < minPrice) {
	        		minPrice = element.getTotPrice();
	        		minPriceTransaction = element;
	        	}
	        	else {
	        		//empty
	        	}
	    	}
	    	return minPriceTransaction;
	    }
    
    public Transaction[] allTransactions() {
    	for(int i =0; i<allTransactions.length;i++) {
    		Transaction transaction = new Transaction();
    		allTransactions[i]= transaction;
    	}
    	return allTransactions;
    }
    public ShopAssistant[] sepTransactions() {
    	shopAssistantsArray = FileIO.getShopAssistants();
    	for (int i = 0; i < shopAssistantsArray.length; i++) {
            Transaction[] transactionsArray = new Transaction[15];
            for (int j = 0; j < 15; j++) {
                transactionsArray[j] = allTransactions[(i*15)+j];
            }
            shopAssistantsArray[i].setTransactionlist(transactionsArray);
        }
    	return shopAssistantsArray;
    }
    public Transaction[][] voidTransactionMatrix(){
    	for (int i = 0; i < shopAssistantsArray.length; i++) {
            for (int j = 0; j < shopAssistantsArray[i].getTransactionlist().length; j++) {
                twoDTransactionMatrix[i][j] = shopAssistantsArray[i].getTransactionlist()[j];
            }
        }
        return twoDTransactionMatrix;
    }
    

    
    
    
    
    
    
}
    
    
    
    
    
    
    
    
    
    
    
    
   
    
