package TransactionApp;


public class SalaryManagement {
	private ShopAssistant[] shopArr;
	
	public SalaryManagement(ShopAssistant[] shopArr){
		this.shopArr = shopArr;
		setAssistantSalary();
	}
	
	public ShopAssistant[] getShopArr() {
		return shopArr;
	}

	public void setAssistantSalary() {
		for(int i=0; i<shopArr.length;i++) {
			double totalRevenue = shopArr[i].calculateTotalRevenue();
			int weeklySalary = shopArr[i].RandomWeeklySalary(shopArr[i].getShopAssistantseniority());
			double commission = shopArr[i].CommisionCalc(totalRevenue);
			shopArr[i].setShopAssistanSalary((weeklySalary * 4) + commission);
			shopArr[i].setComission(commission);
		}
	}
	public double calculateTotalRevenueForAllAssistants(ShopAssistant[] shopassistantArr) {
	    double totalRevenueForAllAssistant = 0;

	    ShopAssistant[] shopAssistants = shopassistantArr;

	    for (ShopAssistant shopAssistant : shopAssistants) {
	        double AssistantRevenue = shopAssistant.calculateTotalRevenue();
	        totalRevenueForAllAssistant += AssistantRevenue;
	    }

	    return totalRevenueForAllAssistant;
	}
	 public double calculateTotalAssistantSalaries() {
		    double totalAssistantSalaries = 0.0;

		    for (int i = 0; i < shopArr.length; i++) {
		        totalAssistantSalaries += shopArr[i].getShopAssistanSalary();
		    }

		    return totalAssistantSalaries;
		}
	
}





	
	


