package TransactionApp;

import java.util.Random;

public class Transaction {
	private int transID;
	private Product[] threeProductArr;
	private double totPrice ;
	private double transFee;
	private static int idCounter = 0;
	private Product maxProduct ;
	
	
	
    

	public Product getMaxProduct() {
		return maxProduct;
	}

	public void setMaxProduct(Product maxProduct) {
		this.maxProduct = maxProduct;
	}

	public Product[] getThreeProductArr() {
		return threeProductArr;
	}

	public void setThreeProductArr(Product[] threeProductArr) {
		this.threeProductArr = threeProductArr;
	}

	public double getTotPrice() {
		return totPrice;
	}

	public void setTotPrice(double totPrice) {
		this.totPrice = totPrice;
	}

	public double getTransFee() {
		return transFee;
	}

	public void setTransFee(double transFee) {
		this.transFee = transFee;
	}

	public static int getIdCounter() {
		return idCounter;
	}

	public static void setIdCounter(int idCounter) {
		Transaction.idCounter = idCounter;
	}

	public void setTransID(int transID) {
		this.transID = transID;
	}

	public Transaction() {
        this.threeProductArr = RandomProduct();
        this.totPrice = TotPriceCalc();
        this.transFee = TransFeeCalc();
        this.transID = idCounter;
        idCounter++;
        maxProduct = findMaxProdPrice(); 
        
    }

    protected Product[] RandomProduct() {
		
		Product[] threeProductArr = new Product[3];
		Product [] products = FileIO.getProducts();
	
		for(int i = 0; i <threeProductArr.length; i++) {
			int rand = new Random().nextInt(products.length);
			threeProductArr[i] = products[rand];
		}
		return threeProductArr;
	}
	
	protected double TotPriceCalc() {
		double totPrice = 0;
		for(Product obj : this.threeProductArr) {
			totPrice += obj.getPrice() * obj.getQuantity();
		}
		return totPrice;
	}
	
	protected double TransFeeCalc() {
		this.TotPriceCalc();
		if(totPrice <= 499) {
			transFee = totPrice/100;
			return transFee;
		}
		else if(totPrice <= 799){
			transFee = (totPrice*3)/100;
			return transFee;
		}
		else if(totPrice <= 999){
			transFee = (totPrice*5)/100;
			return transFee;
		}
		else{
			transFee = (totPrice*9)/100;
			return transFee;
		}
	}
	public Product findMaxProdPrice() {
		double maxProductPrice = this.threeProductArr[0].getPrice();
		
		for (int i = 0;i<threeProductArr.length;i++) {
			if(maxProductPrice<=threeProductArr[i].getPrice()) {
				maxProduct = threeProductArr[i];
				
			}
		}
		return maxProduct;
	}
	public int getTransID() {
        return transID;
    }

    public double getTransactionFee() {
        return transFee;
    }
	

	
	
}