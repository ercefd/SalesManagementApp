package TransactionApp;

import java.util.Random;

public class Product {
	private int productID;
	private String productName;
	private Double price;
	private int quantity;
	
	public Product(int productID, String productName, Double price) {
		this.productID = productID;
		this.productName = productName;
		this.price = price;
		this.quantity = setRandomQuantity();
	}
	
	private int setRandomQuantity() {
		Random rand = new Random();
		int quantity = rand.nextInt(10)+1;
		return quantity;
	}
	public int getId() {
		return productID;
	}
	
	public String getProductName() {
		return productName;
	}
	
	public Double getPrice() {
		return price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	
	
	
	
	
}