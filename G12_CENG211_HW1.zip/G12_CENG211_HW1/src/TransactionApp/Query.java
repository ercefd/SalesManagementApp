package TransactionApp;

public class Query {
	TransactionManagement transactionManagement = new TransactionManagement();
	
    
    
	public double highestTransactionPrice() {
        double maxPrice = 0;
        
        for(Transaction element: transactionManagement.allTransactions()) {
        	if(element.getTotPrice() > maxPrice) {
        		maxPrice = element.getTotPrice();
        	}
        	else {
        		//empty
        	}
        }
		
		return maxPrice;
    }
	
	public String ProductExpensive() {
		return transactionManagement.getMinPriceTransaction().getMaxProduct().getProductName();
    }

	public double LowestFeeT() {
		double lowestFee = 50000;
		
		for(Transaction element: transactionManagement.allTransactions()) {
        	if(element.getTransFee() < lowestFee) {
        		lowestFee = element.getTransFee();
        	}
        	else {
        		//empty
        	}
        }
		
        return lowestFee;
    }
	
	public String getHighestSalaryAssistant() {
		int id = 0;
		String name = "";
		int seniority = 0;
		int weeklyBasSal = 0;
		double commission = 0;
		double maxSalary = 0;
		ShopAssistant[] shopAssistantArray = transactionManagement.getShopAssistantsArray();
		for(int i =0;i< shopAssistantArray.length;i++) {
			
        	if(shopAssistantArray[i].getShopAssistanSalary() > maxSalary) {
        		maxSalary = shopAssistantArray[i].getShopAssistanSalary();
        		id = shopAssistantArray[i].getShopAssistantID();
        		name = shopAssistantArray[i].getShopAssistantname();
        		seniority = shopAssistantArray[i].getShopAssistantseniority();
        		weeklyBasSal = shopAssistantArray[i].RandomWeeklySalary(seniority);
        		commission = shopAssistantArray[i].getComission();
        		
        	}
        	else {
        		//empty
        	}
        }
        return "The highest salary shop assistant :\n	Id : " + id + "\n	Name : " + name + "\n	Seniority : " + seniority + "\n	Weekly Salary Basis : " + weeklyBasSal + "\n	Commission : " + commission + "\n	Salary : " + maxSalary;
    }
	
	 public void TotRevenuePriceFee() {
	        System.out.println("Total Revenue: " + transactionManagement.getSalaryManagement().calculateTotalRevenueForAllAssistants(transactionManagement.getShopAssistantsArray()));
	    }	 	
		
		
	 public double calculateProfit() {
	        
	        return  transactionManagement.getSalaryManagement().calculateTotalRevenueForAllAssistants(transactionManagement.getShopAssistantsArray()) -
	        		transactionManagement.getSalaryManagement().calculateTotalAssistantSalaries();
	    }
	 public void print() {
		 System.out.println("Highest total price transaction is : " + highestTransactionPrice());
	      System.out.println("The most expensive product in the lowest price transaction : " + ProductExpensive());
	      System.out.println("The lowest transaction fee : " + LowestFeeT());
	      System.out.println(getHighestSalaryAssistant());
	      TotRevenuePriceFee();
	      System.out.println("Total Profit: " + calculateProfit());
	 }

}
