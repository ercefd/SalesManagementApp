package TransactionApp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileIO {
	public static Product[] getProducts() {
        Product[] products = new Product[90];
        try {
            FileReader fileReader = new FileReader("products.csv");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;

            int i = 0;
            while ((line = bufferedReader.readLine()) != null) {

                String[] values = line.split(";");
                String priceS = values[2].replace(",", ".");
                double priceD = Double.parseDouble(priceS);
                Product product = new Product(Integer.parseInt(values[0]), values[1], priceD);
                products[i] = product;

                i++;
            }

            bufferedReader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return products;
    }
	public static ShopAssistant[] getShopAssistants() {
        ShopAssistant[] assistantsArray = new ShopAssistant[100];

        try {
            FileReader fileReader = new FileReader("shopAssistants.csv");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;

            int i = 0;
            while ((line = bufferedReader.readLine()) != null) {

                String[] values = line.split(";");

                ShopAssistant shopAssistant = new ShopAssistant(Integer.parseInt(values[0]), values[1], values[2], (values[3]));

                assistantsArray[i] = shopAssistant;

                i++;
            }

            bufferedReader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return assistantsArray;
    }
}

