package TransactionApp;

public class SalesManagementApp {

	public static void main(String[] args) {
		
	  Query query = new Query();
      query.print();
	}
}
