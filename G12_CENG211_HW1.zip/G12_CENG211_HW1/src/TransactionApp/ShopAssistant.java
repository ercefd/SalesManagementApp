package TransactionApp;

import java.util.Random;

public class ShopAssistant {
	private int shopAssistantID;
	private String shopAssistantname;
	private String shopAssistantsurname;
	private String shopAssistantphoneNumber;
	private int shopAssistantseniority;
	private Transaction[] transactionlist = new Transaction[15];
	private double ShopAssistanSalary ;
	private double totalRevenue;
	private double comission;
	
	
	public ShopAssistant(int shopAssistantID, String shopAssistantname, String shopAssistantsurname, String shopAssistantphoneNumber) {
		this.shopAssistantID = shopAssistantID;
		this.shopAssistantname = shopAssistantname;
		this.shopAssistantsurname = shopAssistantsurname;
		this.shopAssistantphoneNumber = shopAssistantphoneNumber;
		this.shopAssistantseniority = setRandomSeniority();
		this.totalRevenue = calculateTotalRevenue();
		this.comission = CommisionCalc(this.totalRevenue); 
		
	}
	
	public double getTotalRevenue() {
		return totalRevenue;
	}

	public void setTotalRevenue(double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}

	public double getComission() {
		return comission;
	}

	public void setComission(double comission) {
		this.comission = comission;
	}

	public void setTransactionlist(Transaction[] transactionlist) {
		this.transactionlist = transactionlist;
	}

	public int RandomWeeklySalary(int ShopAssistantseniority) {
        if (ShopAssistantseniority < 1) {
            return 1500;
        } else if (ShopAssistantseniority < 3) {
            return 2000;
        } else if (ShopAssistantseniority < 5) {
            return 2500;
        } else {
            return 3000;
        }
    }
	public double CommisionCalc(double totalRevenue) {
        if (totalRevenue > 7500) {
            return totalRevenue * 0.03;
        } else {
            return totalRevenue * 0.01;
        }
    }
    public double calculateTotalRevenue() {
        double totalRevenue = 0.0;
        for (Transaction transaction : transactionlist) {
            if (transaction != null) {
            	for (Product product : transaction.getThreeProductArr()) {
            		totalRevenue += product.getPrice()*product.getQuantity();

            }
        }
    }
        return totalRevenue;
    }
	
	public double getShopAssistanSalary() {
		return ShopAssistanSalary;
	}
	public void setShopAssistanSalary(double shopAssistanSalary) {
		ShopAssistanSalary = shopAssistanSalary;
	}
	
	public Transaction[] getTransactionlist() {
		return transactionlist;
	}
	public void setTransactions(Transaction[] transactions) {
		this.transactionlist = transactionlist;
	}

	public void setShopAssistantID(int shopAssistantID) {
		this.shopAssistantID = shopAssistantID;
	}

	public void setShopAssistantname(String shopAssistantname) {
		this.shopAssistantname = shopAssistantname;
	}

	public void setShopAssistantsurname(String shopAssistantsurname) {
		this.shopAssistantsurname = shopAssistantsurname;
	}

	public void setShopAssistantphoneNumber(String shopAssistantphoneNumber) {
		this.shopAssistantphoneNumber = shopAssistantphoneNumber;
	}

	public void setShopAssistantseniority(int shopAssistantseniority) {
		this.shopAssistantseniority = shopAssistantseniority;
	}

	
	
	public int getShopAssistantID() {
		return shopAssistantID;
	}

	public String getShopAssistantname() {
		return shopAssistantname;
	}

	public String getShopAssistantsurname() {
		return shopAssistantsurname;
	}

	public String getShopAssistantphoneNumber() {
		return shopAssistantphoneNumber;
	}

	public int getShopAssistantseniority() {
		return shopAssistantseniority;
	}

	private int setRandomSeniority() {
		return new Random().nextInt(15) + 1;
	}
	
	
}